CHRISTMAS SNOW MODULE
------------------

Christmas Snow Module:
By: introfini & rmiddle

Licensed under the GNU/GPL License
snowflakes.jo is Licensed under the BSD License see http://www.schillmania.com/projects/snowstorm/


---------------------------------------------------------------------------------------------------------

Pre-Installation
-----------------

As of 7.x-1.x the snowflakes.js file is included with the plug-in to make instation easier.

You are welcome to hack the module if you want the lights and submit a patch :-)


Installation
------------
1. Copy christmas_snow folder to modules directory
2. At admin/modules enable the module
3. It's done
